import sys
from npb.gui import main

if __name__ == "__main__":
    sys.exit(main())

