from setuptools import setup, find_packages
import subprocess
import json
import os
import atexit
import sys

def post_install_message():
    print("\nInstallation is nearly complete. Please follow the next steps manually:")
    print("""
    To fully enable all functionalities of this package, you must install additional dependencies via Conda:
    1. Install vmd-python:
        conda install -c conda-forge vmd-python
    2. Install psfgen:
        conda install conda-forge::psfgen
    """)

def find_conda():
    """ Attempt to find a 'conda' executable in the system path. """
    conda_exec = 'conda'  # Default, works if 'conda' is in the PATH
    for path in os.environ.get('PATH', '').split(os.pathsep):
        potential_conda = os.path.join(path, conda_exec)
        if os.path.exists(potential_conda) and os.access(potential_conda, os.X_OK):
            return potential_conda
    return None  # Return None if not found

def attempt_conda_install():
    conda_path = find_conda()
    if not conda_path:
        print("Conda executable not found. Please ensure Conda is installed and in the system PATH.")
        return

    try:
        subprocess.run([conda_path, "install", "conda-forge::ambertools", "-y"], check=True, capture_output=True)
        subprocess.run([conda_path, "install", "-c", "conda-forge", "vmd-python", "-y"], check=True, capture_output=True)
        subprocess.run([conda_path, "install", "-c", "conda-forge", "psfgen", "-y"], check=True, capture_output=True)
        subprocess.run([conda_path, "install", "-c", "conda-forge", "pyqt", "-y"], check=True, capture_output=True)
        subprocess.run([conda_path, "install", "-c", "conda-forge", "mdanalysis", "-y"], check=True, capture_output=True)
        print("\nConda packages installed successfully.")
    except subprocess.CalledProcessError as e:
        print(f"\nFailed to install packages via Conda:\nSTDOUT: {e.stdout.decode()}\nSTDERR: {e.stderr.decode()}")


def get_install_dir():
    """Get the installation directory safely."""
    if '__file__' in globals():
        return os.path.dirname(os.path.abspath(__file__))
    else:
        return os.getcwd()

def create_config():
    """Create or update the config.json file based on installation directory."""
    install_dir = get_install_dir()
    config = {
        "main_folder_path": install_dir,
        "enable_logging": True,
        "log_level": "INFO"
    }
    config_path = os.path.join(install_dir, 'config.json')
    with open(config_path, 'w') as f:
        json.dump(config, f, indent=4)
    print("\nConfiguration file created at:", config_path)

def setup_package():
    setup(
        name='nanopolysaccharide_builder',
        version='1.0',
        author='HugoWan; Yanyu',
        author_email='hugowan@student.ubc.ca; yuy1@ornl.gov',
        description='A package for building nanopolysaccharide structures',
        long_description=open('README.md').read(),
        long_description_content_type='text/markdown',
        packages=find_packages(),
        include_package_data=True,
        install_requires=[
            'numpy',
            'pandas',
        ],
        scripts=['run_npb.py'], 
        entry_points={
        'console_scripts': [
            'npb=npb.gui:main'  # Directly points to the main function in your package
        ]
            },
        package_data={
            '': ['*.template', '*.tcl', '*.awk', '*.pdf', '*.txt']
        },
        zip_safe=False
    )

if __name__ == "__main__":
    setup_package()
    attempt_conda_install()
    atexit.register(create_config)  # Register the config file creation to run on exit.
