import MDAnalysis as mda

# Load the PDB file
pdb_file = "left-chain.pdb"
u = mda.Universe(pdb_file)

# Set to collect all unique residue names
residue_names = set()

# Iterate over all residues in the universe
for residue in u.residues:
    residue_names.add(residue.resname)

# Print all unique residue names
print("Unique residue names in the file:")
for resname in sorted(residue_names):
    print(resname)
