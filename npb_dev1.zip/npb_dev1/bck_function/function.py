import MDAnalysis as mda
from MDAnalysis.coordinates import PDB
import warnings
import os
from tkinter import messagebox

warnings.filterwarnings("ignore", category=UserWarning)

def build_left_chain_pdb(iterations, c_trans):
    input_file = "chitin/left-unit.pdb"
    u = mda.Universe(input_file)
    left_chain = []

    for i in range(1, iterations + 1):
        u.atoms.positions += [0, 0, c_trans]
        resid_1 = (iterations - i + 1) * 2 - 1
        resid_2 = (iterations - i + 1) * 2
        for j, atom in enumerate(u.atoms):
            if j < 27:
                atom.residue.resid = resid_1
            else:
                atom.residue.resid = resid_2
        chain_output = f"{i}.pdb"
        left_chain.append(chain_output)
        with mda.Writer(chain_output, n_atoms=u.atoms.n_atoms) as W:
            W.write(u.atoms)

    with open("left-chain_temp.pdb", "w") as chain:
        for chain_output in reversed(left_chain):
            with open(chain_output, "r") as pdb_file:
                for line in pdb_file:
                    if line.startswith("ATOM"):
                        chain.write(line)
            os.remove(chain_output)
    u_final = mda.Universe("left-chain_temp.pdb")
    with mda.Writer("left-chain.pdb", n_atoms=u_final.atoms.n_atoms, reindex=True) as W:
        W.write(u_final.atoms)
    os.remove("left-chain_temp.pdb")
    messagebox.showinfo("Success", "left-chain.pdb has been generated successfully.")

def build_right_chain_pdb(iterations, c_trans):
    input_file = "chitin/right-unit.pdb"
    u = mda.Universe(input_file)
    right_chain = []

    for i in range(1, iterations + 1):
        u.atoms.positions += [0, 0, c_trans]
        resid_1 = i * 2 - 1
        resid_2 = i * 2
        for j, atom in enumerate(u.atoms):
            if j < 27:
                atom.residue.resid = resid_1
            else:
                atom.residue.resid = resid_2
        chain_output = f"{i}.pdb"
        right_chain.append(chain_output)
        with mda.Writer(chain_output, n_atoms=u.atoms.n_atoms) as W:
            W.write(u.atoms)

    with open("right-chain_temp.pdb", "w") as chain:
        for chain_output in right_chain:
            with open(chain_output, "r") as pdb_file:
                for line in pdb_file:
                    if line.startswith("ATOM"):
                        chain.write(line)
            os.remove(chain_output)
    u_final = mda.Universe("right-chain_temp.pdb")
    with mda.Writer("right-chain.pdb", n_atoms=u_final.atoms.n_atoms, reindex=True) as W:
        W.write(u_final.atoms)
    os.remove("right-chain_temp.pdb")
    messagebox.showinfo("Success", "right-chain.pdb has been generated successfully.")

def build_left_layer_pdb(x_trans, iterations_x):
    left_layer_input_file = "left-chain.pdb"
    u = mda.Universe(left_layer_input_file)
    left_layer = []

    for i in range(1, iterations_x + 1):
        u.atoms.positions += [x_trans, 0, 0]
        left_layer_output = f"layer_left_{i}.pdb"
        left_layer.append(left_layer_output)
        with mda.Writer(left_layer_output, n_atoms=u.atoms.n_atoms) as W:
            W.write(u.atoms)

    with open("left-layer_temp.pdb", "w") as layer_file:
        for left_layer_output in left_layer:
            with open(left_layer_output, "r") as pdb_file:
                for line in pdb_file:
                    if line.startswith("ATOM"):
                        layer_file.write(line)
            os.remove(left_layer_output)

    u_final = mda.Universe("left-layer_temp.pdb")
    with mda.Writer("left-layer.pdb", n_atoms=u_final.atoms.n_atoms, reindex=True) as W:
        W.write(u_final.atoms)
    os.remove("left-layer_temp.pdb")
    messagebox.showinfo("Success", "left-layer.pdb has been generated successfully.")

def build_right_layer_pdb(x_trans, iterations_x):
    right_layer_input_file = "right-chain.pdb"
    u = mda.Universe(right_layer_input_file)
    right_layer = []
    for i in range(1, iterations_x + 1):
        u.atoms.positions += [x_trans, 0, 0]
        right_layer_output = f"layer_right_{i}.pdb"
        right_layer.append(right_layer_output)
        with mda.Writer(right_layer_output, n_atoms=u.atoms.n_atoms) as W:
            W.write(u.atoms)
    with open("right-layer_temp.pdb", "w") as layer_file:
        for right_layer_output in right_layer:
            with open(right_layer_output, "r") as pdb_file:
                for line in pdb_file:
                    if line.startswith("ATOM"):
                        layer_file.write(line)
            os.remove(right_layer_output)

    u_final = mda.Universe("right-layer_temp.pdb")
    with mda.Writer("right-layer.pdb", n_atoms=u_final.atoms.n_atoms, reindex=True) as W:
        W.write(u_final.atoms)
    os.remove("right-layer_temp.pdb")
    messagebox.showinfo("Success", "right-layer.pdb has been generated successfully.")

def assemble_unit_pdb():
    with open("unit.pdb", "w") as unit_file:
        with open("left-layer.pdb", "r") as left_file:
            for line in left_file:
                if line.startswith("ATOM"):
                    unit_file.write(line)

        with open("right-layer.pdb", "r") as right_file:
            for line in right_file:
                if line.startswith("ATOM"):
                    unit_file.write(line)

    messagebox.showinfo("Success", "unit.pdb has been generated successfully.")
