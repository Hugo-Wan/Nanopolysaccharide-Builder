import MDAnalysis as mda
from MDAnalysis.coordinates import PDB
from MDAnalysis.core.universe import Merge
import warnings
import os

warnings.filterwarnings("ignore", category=UserWarning)
input_file = "unit/alpha_chitin/A_configuration/left-unit.pdb"
u = mda.Universe(input_file)

c_trans = 10.33
c_iterations = 4
chain_filenames = [] 
for i in range(1, c_iterations + 1):
    u.atoms.positions += [0, 0, c_trans]
    resid_1 = (c_iterations - i + 1) * 2 - 1
    resid_2 = (c_iterations - i + 1) * 2
    for j, atom in enumerate(u.atoms):
        if j < 27:
            atom.residue.resid = resid_1
        else:
            atom.residue.resid = resid_2
    chain_output = f"{i}.pdb"
    chain_filenames.append(chain_output)  # Append to the list of filenames
    with mda.Writer(chain_output, n_atoms=u.atoms.n_atoms) as W:
        W.write(u.atoms)

# Now use the list of filenames to write to the combined PDB file
with open("chain_temp.pdb", "w") as chain_file:
    for chain_output in reversed(chain_filenames):
        with open(chain_output, "r") as pdb_file:
            for line in pdb_file:
                if line.startswith("ATOM"):
                    chain_file.write(line)
        os.remove(chain_output)


u_infinite_final = mda.Universe("chain_temp.pdb")
with mda.Writer("chain.pdb", n_atoms=u_infinite_final.atoms.n_atoms, reindex=True) as W:
    W.write(u_infinite_final.atoms)


finite_build_chain = "chain_temp.pdb"
finite_u = mda.Universe(finite_build_chain)
first_atom = finite_u.atoms[0]
o4_atoms = finite_u.select_atoms("name O4")
if not o4_atoms:
    raise ValueError("No atoms named 'O4' found in the structure.")
last_o4 = o4_atoms[-1]

new_positions = {
    'O1': first_atom.position + [-0.538, -0.449, 1.247],
    'HO1': first_atom.position + [0.129, -0.365, 1.932],
    'HO4': last_o4.position + [0.377, -0.192, -0.892]
}

new_atoms = {}
for name, pos in new_positions.items():
    base_atom = first_atom if name in ['O1', 'HO1'] else last_o4
    new_uni = mda.Universe.empty(n_atoms=1, trajectory=True)
    new_uni.add_TopologyAttr('name', [name])
    new_uni.add_TopologyAttr('type', [base_atom.type])
    new_uni.add_TopologyAttr('resname', [base_atom.resname])
    new_uni.add_TopologyAttr('resid', [base_atom.resid])
    new_uni.add_TopologyAttr('chainIDs', ['N']) 
    new_uni.add_TopologyAttr('segid', ['CARB']) 
    new_uni.atoms.positions = [pos]
    new_atoms[name] = new_uni

# Combine all with the original atoms adjusting segid where required
combined = Merge(finite_u.atoms[:last_o4.index + 1], new_atoms['HO4'].atoms, finite_u.atoms[last_o4.index + 1:])
combined = Merge(combined.atoms[:2], new_atoms['O1'].atoms, combined.atoms[2:])
combined = Merge(combined.atoms[:3], new_atoms['HO1'].atoms, combined.atoms[3:])


for atom in combined.atoms:
    atom.segment.segid = 'CARB'  
combined.atoms.write("chain.pdb")
os.remove("chain_temp.pdb")
print("Generated chitin-fc model.")