import MDAnalysis as mda
from MDAnalysis.coordinates import PDB
from MDAnalysis.core.universe import Merge
from MDAnalysis.core.groups import AtomGroup
from MDAnalysis.coordinates.PDB import PDBWriter
from vmd import atomsel, molecule
import math
import copy
import random
import numpy as np
import warnings
import os
import glob
import shutil
warnings.filterwarnings("ignore", category=UserWarning)



#-------------------------------------------- modified parameter  --------------------------------------------------
DDA_target=0.20                #deacetylation degree ref:10.1021/acs.jchemed.7b00902J
pH=3                           #pH condition
pKa=6.3                        #pka of chitosan  ref:doi.org/10.1016/j.foodhyd.2022.108383
c_trans = 10.33
c_iterations = 4
m_GlcNAc = 204.20              # GlcNAc unit mass
m_Glc = 179.17                 # Glc unit mass
#-------------------------------------------- modified parameter  --------------------------------------------------




#-------------------------------------------------- native chitin built ----------------------------------------------
left_chain_input_file = "unit/alpha_chitin/A_configuration/left-unit.pdb"
right_chain_input_file = "unit/alpha_chitin/A_configuration/right-unit.pdb"
l_u = mda.Universe(left_chain_input_file)
r_u = mda.Universe(right_chain_input_file)
a_trans = 4.74 
b_trans = 18.86
c_trans = 10.33

a_iterations = 8
b_iterations = 2  
c_iterations = 4


 #left_chain assembly    
 #------------------------------------------------------------------------------
left_chain = []
for l_i in range(1, c_iterations + 1):
    l_u.atoms.positions += [0, 0, c_trans]
    resid_1 = (c_iterations - l_i + 1) * 2 - 1
    resid_2 = (c_iterations - l_i + 1) * 2
    for j, atom in enumerate(l_u.atoms):
        if j < 27:
            atom.residue.resid = resid_1
        else:
            atom.residue.resid = resid_2
    left_chain_output = f"l-{l_i}.pdb"
    left_chain.append(left_chain_output)
    with mda.Writer(left_chain_output, n_atoms=l_u.atoms.n_atoms) as W:
        W.write(l_u.atoms)
with open("left-chain_temp.pdb", "w") as l_chain:
    for l_chain_output in reversed(left_chain):
        with open(l_chain_output, "r") as lef_chain_pdb_file:
            for left_chain_line in lef_chain_pdb_file:
                if left_chain_line.startswith("ATOM"):
                    l_chain.write(left_chain_line)
            os.remove(l_chain_output) 

 ##terminal side            
left_finite_build_chain = "left-chain_temp.pdb"
left_finite_u = mda.Universe(left_finite_build_chain)
left_first_atom = left_finite_u.atoms[0]
o4_atoms = left_finite_u.select_atoms("name O4")
if not o4_atoms:
    raise ValueError("No atoms named 'O4' found in the structure.")
last_o4 = o4_atoms[-1]

new_positions = {
    'O1': left_first_atom.position + [-0.538, -0.449, 1.247],
    'HO1': left_first_atom.position + [0.129, -0.365, 1.932],
    'HO4': last_o4.position + [0.377, -0.192, -0.892]
}

left_new_atoms = {}
for name, pos in new_positions.items():
    left_base_atom = left_first_atom if name in ['O1', 'HO1'] else last_o4
    left_new_uni = mda.Universe.empty(n_atoms=1, trajectory=True)
    left_new_uni.add_TopologyAttr('name', [name])
    left_new_uni.add_TopologyAttr('type', [left_base_atom.type])
    left_new_uni.add_TopologyAttr('resname', [left_base_atom.resname])
    left_new_uni.add_TopologyAttr('resid', [left_base_atom.resid])
    left_new_uni.add_TopologyAttr('chainIDs', ['N'])
    left_new_uni.add_TopologyAttr('segid', ['CARB']) 
    left_new_uni.atoms.positions = [pos]
    left_new_atoms[name] = left_new_uni

left_combined = Merge(left_finite_u.atoms[:last_o4.index + 1], left_new_atoms['HO4'].atoms, left_finite_u.atoms[last_o4.index + 1:])
left_combined = Merge(left_combined.atoms[:2], left_new_atoms['O1'].atoms, left_combined.atoms[2:])
left_combined = Merge(left_combined.atoms[:3], left_new_atoms['HO1'].atoms, left_combined.atoms[3:])

for atom in left_combined.atoms:
    atom.segment.segid = 'CARB'  
left_combined.atoms.write("left-chain_temp.2.pdb")
#------------------------------------------------------------------------------




#right_chain assembly      
#------------------------------------------------------------------------------ 
right_chain = []
for r_i in range(1, c_iterations + 1):
    r_u.atoms.positions += [0, 0, c_trans]
    resid_1 = r_i  * 2 - 1
    resid_2 = r_i  * 2
    for j, atom in enumerate(r_u.atoms):
        if j < 27:
            atom.residue.resid = resid_1
        else:
            atom.residue.resid = resid_2
    right_chain_output = f"r-{r_i}.pdb"
    right_chain.append(right_chain_output)
    with mda.Writer(right_chain_output, n_atoms=r_u.atoms.n_atoms) as W:
        W.write(r_u.atoms)
with open("right-chain_temp.pdb", "w") as chain:
    for r_chain_output in right_chain:
         with open(r_chain_output, "r") as right_chain_pdb_file:
            for right_chain_line in right_chain_pdb_file:
                if right_chain_line.startswith("ATOM"):
                    chain.write(right_chain_line)
            os.remove(r_chain_output)

##terminal side 
right_finite_build_chain = "right-chain_temp.pdb"
right_finite_u = mda.Universe(right_finite_build_chain)
right_first_atom = right_finite_u.atoms[0]
o4_atoms = right_finite_u.select_atoms("name O4")
if not o4_atoms:
    raise ValueError("No atoms named 'O4' found in the structure.")
last_o4 = o4_atoms[-1]

new_positions = {
    'O1': right_first_atom.position - [-0.538, -0.449, 1.247],
    'HO1': right_first_atom.position - [0.129, -0.365, 1.932],
    'HO4': last_o4.position - [0.377, -0.192, -0.892]
}

right_new_atoms = {}
for name, pos in new_positions.items():
    right_base_atom = right_first_atom if name in ['O1', 'HO1'] else last_o4
    right_new_uni = mda.Universe.empty(n_atoms=1, trajectory=True)
    right_new_uni.add_TopologyAttr('name', [name])
    right_new_uni.add_TopologyAttr('type', [right_base_atom.type])
    right_new_uni.add_TopologyAttr('resname', [right_base_atom.resname])
    right_new_uni.add_TopologyAttr('resid', [right_base_atom.resid])
    right_new_uni.add_TopologyAttr('chainIDs', ['N']) 
    right_new_uni.add_TopologyAttr('segid', ['CARB']) 
    right_new_uni.atoms.positions = [pos]
    right_new_atoms[name] = right_new_uni

right_combined = Merge(right_finite_u.atoms[:last_o4.index + 1], right_new_atoms['HO4'].atoms, right_finite_u.atoms[last_o4.index + 1:])
right_combined = Merge(right_combined.atoms[:2], right_new_atoms['O1'].atoms, right_combined.atoms[2:])
right_combined = Merge(right_combined.atoms[:3], right_new_atoms['HO1'].atoms, right_combined.atoms[3:])
for atom in right_combined.atoms:
    atom.segment.segid = 'CARB'  
right_combined.atoms.write("right-chain_temp.2.pdb")

#------------------------------------------------------------------------------


 #left_layer assembly  
left_layer_input_file = "left-chain_temp.2.pdb"
layer_l_u = mda.Universe(left_layer_input_file)
left_layer = []  
for i in range(1, a_iterations + 1):
    layer_l_u.atoms.positions += [a_trans, 0, 0]
    left_layer_output = f"left_layer_{i}.pdb"
    left_layer.append(left_layer_output)
    with mda.Writer(left_layer_output, n_atoms=layer_l_u.atoms.n_atoms) as W:
        W.write(layer_l_u.atoms)
with open("left-layer_temp.pdb", "w") as layer_file:
    for left_layer_output in left_layer:
        with open(left_layer_output, "r") as left_layer_pdb_file:
            for left_layer_line in left_layer_pdb_file:
                if left_layer_line.startswith("ATOM"):
                    layer_file.write(left_layer_line)
            os.remove(left_layer_output) 


 #right_layer assembly    
right_layer_input_file = "right-chain_temp.2.pdb"
layer_r_u = mda.Universe(right_layer_input_file)
right_layer = []  
for i in range(1, a_iterations + 1):
    layer_r_u .atoms.positions += [a_trans, 0, 0]
    right_layer_output = f"right_layer_{i}.pdb"
    right_layer.append(right_layer_output)
    with mda.Writer(right_layer_output, n_atoms=layer_r_u .atoms.n_atoms) as W:
        W.write(layer_r_u .atoms)
with open("right-layer_temp.pdb", "w") as layer_file:
    for right_layer_output in right_layer:
        with open(right_layer_output, "r") as right_layer_pdb_file:
            for right_layer_line in right_layer_pdb_file:
                if right_layer_line.startswith("ATOM"):
                    layer_file.write(right_layer_line)
            os.remove(right_layer_output) 


 #unit_structure assembly  
left_layer_input_file = "left-layer_temp.pdb"
right_layer_input_file = "right-layer_temp.pdb"
unit_output_file = "unit.pdb" 
with open(unit_output_file, "w") as unit_file:
    with open("left-layer_temp.pdb", "r") as left_file:
        for line in left_file:
            if line.startswith("ATOM"):
                unit_file.write(line)
    with open("right-layer_temp.pdb", "r") as right_file:
        for line in right_file:
            if line.startswith("ATOM"):
                unit_file.write(line)

unit_input_file="unit.pdb"
crystal_structure = mda.Universe(unit_input_file)
crystal_structure_files = [] 
for crystal_i in range(1, b_iterations + 1):
    crystal_structure.atoms.positions += [0, -1 * b_trans, 0]
    crystal_structure_output = f"crystal_{crystal_i}.pdb"
    crystal_structure_files.append(crystal_structure_output)
    with mda.Writer(crystal_structure_output, n_atoms=crystal_structure.atoms.n_atoms) as W:
        W.write(crystal_structure.atoms)

with open("alpha-chitin-A-temp.pdb", "w") as crystal_file:
    for crystal_structure_output in crystal_structure_files:
        with open(crystal_structure_output, "r") as crystal_pdb_file:
            for crystal_line in crystal_pdb_file:
                if crystal_line.startswith("ATOM"):
                    crystal_file.write(crystal_line)
            os.remove(crystal_structure_output) 
os.remove(unit_input_file)


#-------------------------------------------------- native chitin built ----------------------------------------------




#------------------------------------------------- nh3 modified step -------------------------------------------------------


###########NH3 located step

chain_u = mda.Universe("alpha-chitin-A-temp.pdb")
residue_ids = [residue.resid for residue in chain_u.residues]
total_residues=len(residue_ids)

#print("Left Modified Chains:", left_modified_chains)
#print("Right Modified Chains:", right_modified_chains)


###NHx group evenly assigned to each chain
##define the dda; how many resiudes should be modified:
def calculate_dda(x):
    numerator = (total_residues - x) * m_Glc
    denominator = numerator + x * m_GlcNAc
    return numerator / denominator if denominator != 0 else 0

def adjust_closest_x_for_positive_integer(closest_x, total_residues, a_iterations):
    remainder = (total_residues - closest_x) % (2 * a_iterations)
    if remainder != 0:
        closest_x += remainder
    if (total_residues - closest_x) // (2 * a_iterations) <= 0:
        closest_x -= (2 * a_iterations)
    return max(0, closest_x)

def adjust_for_amination_limit(closest_x, total_residues, a_iterations, c_iterations):
    amination_number = total_residues - closest_x
    modified_num_per_chain = amination_number / (2 * a_iterations)
    if modified_num_per_chain > c_iterations:
        # Reduce amination_number to 2 * c * a_iterations
        new_amination_number = 2 * c_iterations * a_iterations
        closest_x = total_residues - new_amination_number
    return closest_x

closest_x = None
closest_dda = float('inf')
for x in range(total_residues + 1):
    dda = calculate_dda(x)
    if abs(dda - DDA_target) < abs(closest_dda - DDA_target):
        closest_x = x
        closest_dda = dda

closest_x = adjust_closest_x_for_positive_integer(closest_x, total_residues, a_iterations)
closest_x = adjust_for_amination_limit(closest_x, total_residues, a_iterations, c_iterations)

aminiation_number = total_residues - closest_x
modified_num_per_chain = aminiation_number / (2 * a_iterations)
if (total_residues - closest_x) % (2 * a_iterations) == 0 and (total_residues - closest_x) // (2 * a_iterations) > 0:
    actual_dda=(aminiation_number*179.17)/(aminiation_number*179.17 + (total_residues-aminiation_number)*204.20)
    #print(f"Actual DDA is : {actual_dda}")
    #print(f"aminiation_number: {aminiation_number}")
    #print(f"aminiation_number_per_chain: {modified_num_per_chain}")
else:
    print("No valid closest_x could be found that meets all criteria.")

actual_dda_rounded=round(actual_dda,2)

###select the range


###selected_chains
left_nacetyl_chains_fragment_number= a_iterations - 1
right_nacetyl_chains_fragment_number_i= a_iterations * 2 * b_iterations - a_iterations
right_nacetyl_chains_fragment_number_j= a_iterations * 2 * b_iterations -1



def get_fragment_indices(mol_id, start_fragment, end_fragment):
    n_acetyl_chain_indices = []
    for fragment_number in range(start_fragment, end_fragment+1):
        # Select atoms belonging to the specified fragment number
        fragment_selection = atomsel(f"fragment {fragment_number}", molid=mol_id)
        
        # Get the indices of these atoms and extend the list
        indices = fragment_selection.index
        n_acetyl_chain_indices.extend(indices)
    
    return n_acetyl_chain_indices


origin_nacetyl_chains = molecule.load("pdb", "alpha-chitin-A-temp.pdb")
left_nacetyl_candidates_indices = get_fragment_indices(origin_nacetyl_chains, 0, left_nacetyl_chains_fragment_number)
right_nacetyl_candidates_indices = get_fragment_indices(origin_nacetyl_chains, right_nacetyl_chains_fragment_number_i, right_nacetyl_chains_fragment_number_j)
left_ndx_i = left_nacetyl_candidates_indices[0]
left_ndx_j = left_nacetyl_candidates_indices[-1]
right_ndx_i = right_nacetyl_candidates_indices[0]
right_ndx_j = right_nacetyl_candidates_indices[-1]
molecule.delete(origin_nacetyl_chains)
#print(len(right_nacetyl_candidates_indices))

left_modified_atoms=chain_u.select_atoms(f"index {left_ndx_i} : {left_ndx_j}")
right_modified_atoms=chain_u.select_atoms(f"index {right_ndx_i} : {right_ndx_j}")


max_range = c_iterations * 2
def right_odd_numbers(count, end):
    count = int(count)
    odd_numbers = list(range(1, end + 1, 2))
    random.shuffle(odd_numbers)
    selected_odds = odd_numbers[:count]
    return selected_odds
right_modified_resid = right_odd_numbers(modified_num_per_chain, max_range)
#print("Randomly generated odd numbers:", right_modified_resid)

def left_even_numbers(count, end):
    count = int(count)
    even_numbers = list(range(2, end + 1, 2))
    random.shuffle(even_numbers)
    selected_evens = even_numbers[:count]
    return selected_evens
left_modified_resid = left_even_numbers(modified_num_per_chain, max_range)
#print("Randomly generated even numbers:", left_modified_resid)


###N-acetyl reomve step
def load_universe(pdb_file):
    return mda.Universe(pdb_file)

def n_acetyl_collect_removal_candidates(universe, start_idx, end_idx, modified_residues):
    n_acetyl_candidates_to_remove = []
    residue_selector = f"resid {' '.join(map(str, modified_residues))} and (bynum {start_idx}:{end_idx})"
    residues = universe.select_atoms(residue_selector).residues
    
    for residue in residues:
        if residue.resid == 1:
            n_acetyl_candidates_to_remove.extend(residue.atoms[10:17].indices)  
        else:
            n_acetyl_candidates_to_remove.extend(residue.atoms[8:15].indices) 
    return n_acetyl_candidates_to_remove



def apply_N_acetyl_removals(universe, candidates_to_remove):
    """Remove the collected candidate atoms from the universe and create a new modified universe."""
    all_indices = set(range(len(universe.atoms)))
    remaining_indices = all_indices - set(candidates_to_remove)
    remaining_atoms = universe.atoms[list(remaining_indices)]
    no_nacetyl = mda.Merge(remaining_atoms)
    return no_nacetyl

native_chitin_file = "alpha-chitin-A-temp.pdb"
original_chitin_crystal = load_universe(native_chitin_file)
    

  # Collect candidates and apply removals
left_nacetyl_candidates = n_acetyl_collect_removal_candidates(original_chitin_crystal, left_ndx_i, left_ndx_j, left_modified_resid)
right_nacetyl_candidates = n_acetyl_collect_removal_candidates(original_chitin_crystal, right_ndx_i, right_ndx_j, right_modified_resid)

# Combine candidates from both sides
all_candidates_to_remove = set(left_nacetyl_candidates + right_nacetyl_candidates)
modified_universe = apply_N_acetyl_removals(original_chitin_crystal, all_candidates_to_remove)

modified_universe.atoms.write("modified-alpha-chitin-temp.pdb")







####nh3_adding step
#####-----------------------------------------left_nh3-side
removal_left_nacetyl_chains = molecule.load("pdb", "modified-alpha-chitin-temp.pdb")
left_removal_indices = get_fragment_indices(removal_left_nacetyl_chains, 0, left_nacetyl_chains_fragment_number)
left_removal_ndx_i = left_removal_indices[0]
left_removal_ndx_j = left_removal_indices[-1]
molecule.delete(removal_left_nacetyl_chains)
#print(len(right_removal_indices))



nh3_left_chain = "modified-alpha-chitin-temp.pdb"
nh3_left_chain_u = mda.Universe(nh3_left_chain)
left_nh3_atoms = list(nh3_left_chain_u.atoms)
left_selected_residues = nh3_left_chain_u.select_atoms(f"index {left_removal_ndx_i}:{left_removal_ndx_j}").residues

# Process each selected residue
for left_sel_residue in left_selected_residues:
    if left_sel_residue .resid in left_modified_resid:
        base_atom_index = 9 if left_sel_residue .resid == 1 else 7
        base_atom = left_sel_residue .atoms[base_atom_index]

        # Define new positions based on residue ID's odd/even status
        if left_sel_residue .resid % 2 == 1:  # Odd residue ID
            left_nh3_new_positions = {
                'HN1': base_atom.position + np.array([0.924, -0.082, 0.374]),
                'HN2': base_atom.position + np.array([-0.667, 0.256, 0.700]),
                'HN3': base_atom.position + np.array([-0.095, -0.607, -0.789])
            }
        else:  # Even residue ID
            left_nh3_new_positions = {
                'HN1': base_atom.position + np.array([-0.529, 0.492, -0.691]),
                'HN2': base_atom.position + np.array([0.890, 0.441, 0.115]),
                'HN3': base_atom.position + np.array([-0.494, -0.013, 0.869])
            }

        # Insert new atoms
        insert_pos = left_nh3_atoms.index(base_atom) + 1
        for name, pos in left_nh3_new_positions.items():
            left_nh3_new_uni = mda.Universe.empty(n_atoms=1, trajectory=True)
            left_nh3_new_uni.add_TopologyAttr('name', [name])
            left_nh3_new_uni.add_TopologyAttr('type', [base_atom.type])
            left_nh3_new_uni.add_TopologyAttr('resname', [base_atom.resname])
            left_nh3_new_uni.add_TopologyAttr('resid', [left_sel_residue.resid])
            left_nh3_new_uni.add_TopologyAttr('segid', ['CARB'])
            left_nh3_new_uni.add_TopologyAttr('chainIDs', ['N'])
            left_nh3_new_uni.atoms.positions = [pos]
            left_nh3_new_atom = left_nh3_new_uni.atoms[0]

            # Insert the new atom at the calculated position
            left_nh3_atoms.insert(insert_pos, left_nh3_new_atom)
            insert_pos += 1  # Update position for the next atom

# Create a new universe with all atoms including the added ones
left_nh3_universe = mda.Merge(*[mda.AtomGroup([atom]) for atom in left_nh3_atoms])
left_nh3_universe.atoms.write("nh3-left-temp.pdb")



#####---------right_nh3-side
removal_right_nacetyl_chains = molecule.load("pdb", "nh3-left-temp.pdb")
right_removal_indices = get_fragment_indices(removal_right_nacetyl_chains, right_nacetyl_chains_fragment_number_i, right_nacetyl_chains_fragment_number_j)
right_removal_ndx_i = right_removal_indices[0]
right_removal_ndx_j = right_removal_indices[-1]
molecule.delete(removal_right_nacetyl_chains)
#print(len(right_removal_indices))


nh3_right_chain = "nh3-left-temp.pdb"
nh3_right_chain_u = mda.Universe(nh3_right_chain)
right_nh3_atoms = list(nh3_right_chain_u.atoms)
right_selected_residues = nh3_right_chain_u.select_atoms(f"index {right_removal_ndx_i}:{right_removal_ndx_j}").residues

# Process each selected residue
for right_sel_residue in right_selected_residues:
    if right_sel_residue .resid in right_modified_resid:
        base_atom_index = 9 if right_sel_residue .resid == 1 else 7
        base_atom = right_sel_residue .atoms[base_atom_index]

        # Define new positions based on residue ID's odd/even status
        if right_sel_residue .resid % 2 == 0:  # even residue ID
            right_nh3_new_positions = {
                'HN1': base_atom.position + np.array([ 0.924, -0.082,  0.374]),
                'HN2': base_atom.position + np.array([-0.667, -0.256,  0.700]),
                'HN3': base_atom.position + np.array([-0.095, -0.607, -0.789])
            }
        else:  # odd residue ID
            right_nh3_new_positions = {
                'HN1': base_atom.position - np.array([-0.529,  0.492, -0.691]),
                'HN2': base_atom.position - np.array([ 0.890,  0.441,  0.115]),
                'HN3': base_atom.position - np.array([ 0.494, -0.013,  0.869])
            }

        # Insert new atoms
        insert_pos = right_nh3_atoms.index(base_atom) + 1
        for name, pos in right_nh3_new_positions.items():
            right_nh3_new_uni = mda.Universe.empty(n_atoms=1, trajectory=True)
            right_nh3_new_uni.add_TopologyAttr('name', [name])
            right_nh3_new_uni.add_TopologyAttr('type', [base_atom.type])
            right_nh3_new_uni.add_TopologyAttr('resname', [base_atom.resname])
            right_nh3_new_uni.add_TopologyAttr('resid', [right_sel_residue.resid])
            right_nh3_new_uni.add_TopologyAttr('segid', ['CARB'])
            right_nh3_new_uni.add_TopologyAttr('chainIDs', ['N'])
            right_nh3_new_uni.atoms.positions = [pos]
            right_nh3_new_atom = right_nh3_new_uni.atoms[0]

            # Insert the new atom at the calculated position
            right_nh3_atoms.insert(insert_pos, right_nh3_new_atom)
            insert_pos += 1  # Update position for the next atom

# Create a new universe with all atoms including the added ones
right_nh3_universe = mda.Merge(*[mda.AtomGroup([atom]) for atom in right_nh3_atoms])
right_nh3_universe.atoms.write("nh3-temp.pdb")





####------------------------------------------------------------nh2 building step----------------------------------------------------------------


#pH calculation |  NH2_step
ratio = 10 ** (pH - pKa)
y = (aminiation_number * ratio) / (1 + ratio)
y_rounded = round(y)

if  y_rounded > 0:
    ratio = y_rounded / aminiation_number
    if ratio > 0:
        actual_pH = math.log10(ratio) + 6.3
        actual_pH_rounded = round(actual_pH, 2)
        #print("Actual pH:", actual_pH_rounded)
else:
    actual_pH_rounded = pH
    #print("Actual pH set to default value:", actual_pH_rounded)



##nh2_number
half, remainder = divmod(y_rounded, 2)
if remainder != 0:
    left_nh2_num = half 
else:
    left_nh2_num = half

right_nh2_num = y_rounded - left_nh2_num

#print("y_rounded:", y_rounded)
#print("left_nh2:", left_nh2_num)
#print("right_nh2:", right_nh2_num)



def load_nh3_universe(pdb_file):
    return mda.Universe(pdb_file)

def collect_nh3_atoms_to_remove_randomly(universe, start_idx, end_idx, modified_residues, number_of_modifications):
    atoms_to_remove = []  # Store indices of atoms to remove
    possible_residues = universe.select_atoms(f"index {start_idx}:{end_idx}").residues
    eligible_residues = [res for res in possible_residues if res.resid in modified_residues]

    # Randomly select residues to modify
    if len(eligible_residues) > number_of_modifications:
        selected_residues = np.random.choice(eligible_residues, size=number_of_modifications, replace=False)
    else:
        selected_residues = eligible_residues

    for residue in selected_residues:
        if residue.resid == 1:
            atoms_to_remove.extend(residue.atoms[12:13].indices)  # Remove specific atoms
            residue.atoms[9].name = 'N2'
            residue.atoms[10].name = 'HN21'
            residue.atoms[11].name = 'HN22'
        else:
            atoms_to_remove.extend(residue.atoms[11:12].indices)  # Remove specific atoms
            residue.atoms[7].name = 'N2'
            residue.atoms[8].name = 'HN21'
            residue.atoms[9].name = 'HN22'

    return atoms_to_remove

def nh2_apply_modifications_and_save(universe, atoms_to_remove, output_name):
    # Remove atoms collected from the original list of indices
    remaining_atoms = universe.select_atoms(f"not bynum {' '.join(map(str, atoms_to_remove))}")
    new_universe = mda.Merge(remaining_atoms)
    new_universe.atoms.write(output_name)
    print("Modification complete. New PDB file written.")


#####---------left_nh2-side
removal_left_nh3_chains = molecule.load("pdb", "nh3-temp.pdb")
left_removal_nh3 = get_fragment_indices(removal_left_nh3_chains, 0, left_nacetyl_chains_fragment_number)
left_removal_nh3_chains_ndx_i = left_removal_nh3[0]
left_removal_nh3_chains_ndx_j = left_removal_nh3[-1]
molecule.delete(removal_left_nh3_chains)


nh2_left_modified_chain = mda.Universe("nh3-temp.pdb")
original_nh3_file = "nh3-temp.pdb"
original_chitin_left_nh3_crystal = load_nh3_universe(original_nh3_file)

nh3_left_atoms_to_remove = collect_nh3_atoms_to_remove_randomly(
    original_chitin_left_nh3_crystal, 
    left_removal_nh3_chains_ndx_i, 
    left_removal_nh3_chains_ndx_j, 
    left_modified_resid, 
    left_nh2_num
)

if left_nh2_num == 0:
    shutil.copy(original_nh3_file, "nh2-left-temp.pdb")  
else:
     nh2_apply_modifications_and_save(original_chitin_left_nh3_crystal, nh3_left_atoms_to_remove, "nh2-left-temp.pdb")






#####---------right_nh2-side
removal_right_nh3_chains = molecule.load("pdb", "nh2-left-temp.pdb")
right_removal_nh3 = get_fragment_indices(removal_right_nh3_chains, right_nacetyl_chains_fragment_number_i, right_nacetyl_chains_fragment_number_j)
right_removal_nh3_chains_ndx_i = right_removal_nh3[0]
right_removal_nh3_chains_ndx_j = right_removal_nh3[-1]
molecule.delete(removal_right_nh3_chains)


nh2_right_modified_chain = mda.Universe("nh2-left-temp.pdb")
original_nh3_right_file = "nh2-left-temp.pdb"
original_chitin_right_nh3_crystal = load_nh3_universe(original_nh3_right_file)

nh3_right_atoms_to_remove = collect_nh3_atoms_to_remove_randomly(
    original_chitin_right_nh3_crystal, 
    right_removal_nh3_chains_ndx_i, 
    right_removal_nh3_chains_ndx_j, 
    right_modified_resid, 
    right_nh2_num
)

if right_nh2_num == 0:
    shutil.copy(original_nh3_right_file, "nh2-temp.pdb")  
else:
    nh2_apply_modifications_and_save(original_chitin_right_nh3_crystal, nh3_right_atoms_to_remove, "nh2-temp.pdb")



u_final = mda.Universe("nh2-temp.pdb")
box_x = a_iterations * a_trans + 20
box_y = b_iterations * b_trans + 20
box_z = c_iterations * c_trans + 20
center_of_mass = u_final.atoms.center_of_mass()
center_of_box = [box_x / 2, box_y / 2, box_z / 2]
u_final.dimensions = [box_x, box_y, box_z, 90, 90, 90]
translation_vector = center_of_box - center_of_mass
u_final.atoms.translate(translation_vector)
with mda.Writer(f"alpha-chitin-A-DDA_{actual_dda_rounded}-pH_{actual_pH_rounded}.pdb", n_atoms=u_final.atoms.n_atoms, reindex=True) as W:
    W.write(u_final.atoms)

# Remove temporary files
for temp_file in glob.glob("*temp*.pdb"):
    os.remove(temp_file)

print("Generated alpha-chitin-A fcm model with surface modification.")