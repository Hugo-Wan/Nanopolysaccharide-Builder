   def populateChitosanTab(self, tab):
        layout = QGridLayout(tab)
        layout.setVerticalSpacing(10)
        layout.setContentsMargins(10, 10, 10, 10)

        self.dpLineEdit = QLineEdit()
        self.unitLineEdit = QLineEdit()
        self.ddaLineEdit = QLineEdit()
        self.phLineEdit = QLineEdit()

        inputs = [
            ("Degree of Polymerization:", self.dpLineEdit),
            ("Unit Repeat Distance (Angstrom):", self.unitLineEdit),
            ("Deacetylation Degree (≥0 and <1):", self.ddaLineEdit),
            ("pH Level:", self.phLineEdit)
        ]
        
        font = QFont("Arial", 13)
        modelTypeLabel = QLabel("Chain Model Type:")
        modelTypeLabel.setFont(font)
        
        self.modelTypeSelector = QComboBox()
        self.modelTypeSelector.setFont(font)
        self.modelTypeSelector.addItem(" ", True)
        self.modelTypeSelector.addItem("CHARMM36 Infinite Chain Model", False)
        self.modelTypeSelector.addItem("CHARMM36 Finite Chain Model", False)
        self.modelTypeSelector.addItem("GLYCAM06 Infinite Chain Model", False)
        self.modelTypeSelector.addItem("GLYCAM06 Finite Chain Model", False)

        for index, (label_text, widget) in enumerate(inputs):
            label = QLabel(label_text)
            label.setFont(font)
            widget.setFont(font)
            layout.addWidget(label, index // 2, 2 * (index % 2), 1, 1, Qt.AlignTop)
            layout.addWidget(widget, index // 2, 2 * (index % 2) + 1, 15, 1, Qt.AlignTop)  #the last two number control inter-layer disatnce
 
        layout.addWidget(modelTypeLabel, 2, 0, 1, 1, Qt.AlignTop)
        layout.addWidget(self.modelTypeSelector, 2, 1, 1, 2, Qt.AlignTop)

        generateButton = QPushButton("Generate Structure")
        font_button = QFont()
        font_button.setPointSize(14)
        generateButton.setFont(font_button) 
        layout.addWidget(generateButton, 3, 0, 2, 5)
        generateButton.clicked.connect(self.chitosanGenerate)

    def chitosanGenerate(self):
        dp = self.dpLineEdit.text()
        unit_distance = self.unitLineEdit.text()
        dda = self.ddaLineEdit.text()
        ph = self.phLineEdit.text()
        modelType = self.modelTypeSelector.currentText()
        base_dir = os.path.dirname(os.path.abspath(__file__))
    
        if modelType in ["CHARMM36 Infinite Chain Model", "CHARMM36 Finite Chain Model"]:
            script_name = "infinite-chain.py" if "Infinite" in modelType else "finite-chain.py"
            folder_name = "charmm36"
        elif modelType in ["GLYCAM06 Infinite Chain Model", "GLYCAM06 Finite Chain Model"]:
            script_name = "infinite-chain.py" if "Infinite" in modelType else "finite-chain.py"
            folder_name = "glycam06"
        else:
            QMessageBox.warning(self, "Configuration Error", "Model type is not configured properly.")
            return
    
        script_path = os.path.join(base_dir, "function", "chitosan", folder_name, script_name)
        command = ["python", script_path, dp, unit_distance, dda, ph]
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    
        if result.returncode == 0:
            output = result.stdout.strip()
            self.chitosanStructurePopup(output)
            self.chitosanTopology() 
        else:
            QMessageBox.warning(self, "Generation Failed")
    
    def chitosanTopology(self):
        modelType = self.modelTypeSelector.currentText()
        base_dir = os.path.dirname(os.path.abspath(__file__))
        script_name = "chitosan_ifc_topgen.py" if "Infinite" in modelType else "chitosan_fc_topgen.py"
        folder_name_i = "glycam06" if "GLYCAM06" in modelType else "charmm36"
        folder_name_j = "chitosan"
    
        script_path = os.path.join(base_dir, "topology", folder_name_i, folder_name_j, script_name)
        command = ["python", script_path]
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    
        if result.returncode == 0:
            self.chitosanTopologyPopup()
        else:
            QMessageBox.warning(self, "Topology Generation Failed")

    def chitosanStructurePopup(self, output):
       parts = output.split(',')
       dda = parts[0].split(':')[1].strip()
       ph = parts[1].split(':')[1].strip()
       units = parts[2].split(':')[1].strip()
       message = f"Chitosan chain was generated successfully!\nActual DDA: {dda}\nActual pH: {ph}\nDeprotonated units: {units}"
       QMessageBox.information(self, "Structure Build Result", message)   


    def chitosanTopologyPopup(self):
        modelType = self.modelTypeSelector.currentText()
        file_name = "glycam06" if "GLYCAM06" in modelType else "CHARMM36"
        message = f"{file_name} topology file was generated successfully."
        QMessageBox.information(self, "Topology Build Result", message)
    

##------------------------------------------------------------------chitosan building-------------------------------------------------------

##----------------------------------------------------------------alpha-chitin building-----------------------------------------------------
    def populateAlphaChitinTab(self, tab):
        mainLayout = QVBoxLayout(tab)  # Primary layout to arrange content vertically
    
        # Top-left alignment for the container
        topLayout = QHBoxLayout()  # Use horizontal layout for top-aligned items
        topLayout.setAlignment(Qt.AlignTop | Qt.AlignLeft)  # Align content to the top left
   
        font = QFont("Arial", 13)
    
        # Label for the dropdown
        label = QLabel("Please select the way to build α-chitin crystallite:")
        label.setFont(font)
        topLayout.addWidget(label)  # Add label to the horizontal layout
        Alpha_comboBox = QComboBox()
        Alpha_comboBox.setFont(font)
        Alpha_comboBox.addItem("Select here")  # Initial empty selection
        Alpha_comboBox.addItem("α-chitin-A")
        Alpha_comboBox.addItem("α-chitin-B")
        Alpha_comboBox.currentIndexChanged.connect(self.updateAlphaChitinOptions)
        topLayout.addWidget(Alpha_comboBox)  # Add combo box to the horizontal layout
    
        mainLayout.addLayout(topLayout)  # Add the top horizontal layout to the main vertical layout
    
        self.alphaStackedWidget = QStackedWidget()
        self.alphaStackedWidget.addWidget(QWidget())  # Add an empty widget for the "Select here" option
        self.setupAlphaAOptions()  # Setup options for α-chitin-A
        self.setupAlphaBOptions()  # Setup options for α-chitin-B
        mainLayout.addWidget(self.alphaStackedWidget)  # Add the stacked widget to the main vertical layout

    def updateAlphaChitinOptions(self, index):
        print("Selected index in Alpha ComboBox:", index)
        if index == 0:
            self.alphaStackedWidget.setVisible(False)
        elif index == 1:
            self.alphaStackedWidget.setCurrentIndex(1)
            self.alphaStackedWidget.setVisible(True)
        elif index == 2:
            self.alphaStackedWidget.setCurrentIndex(2)
            self.alphaStackedWidget.setVisible(True)

    def setupAlphaAOptions(self):
        self.AlphaAOptions = QWidget()
        self.alphaStackedWidget.addWidget(self.AlphaAOptions) 
        layout = QVBoxLayout(self.AlphaAOptions)  # Parent the layout to the widget directly
        layout.setAlignment(Qt.AlignTop)
        Font = QFont("Arial", 13)
    
        radioLayout = QHBoxLayout()
        self.radio1 = QRadioButton("Experimental Data")
        self.radio2 = QRadioButton("DFT-Optimization Data")
        self.radio3 = QRadioButton("User-Self Defined")
        
        self.radio1.setFont(Font)
        self.radio2.setFont(Font)
        self.radio3.setFont(Font)
    
        
        radioLayout.addWidget(self.radio1)
        radioLayout.addWidget(self.radio2)
        radioLayout.addWidget(self.radio3)
        layout.addLayout(radioLayout)
    
        # Widget for additional experimental parameters
        self.experimentalWidget = QWidget()
        expLayout = QVBoxLayout(self.experimentalWidget)
        expLayout.setAlignment(Qt.AlignTop)

 
        # Fixed Parameters (a, b, c)
        paramLabels1 = ["a parameter (angstrom)", "b parameter (angstrom)", "c parameter (angstrom)"]
        defaultValues = ["4.749", "18.889", "10.33"]
        paramLayout1 = QHBoxLayout()
        for label, value in zip(paramLabels1, defaultValues):
            lbl = QLabel(label + ":")
            lbl.setFont(Font)
            le = QLineEdit(value)
            le.setFont(Font)
            le.setReadOnly(True)
            le.setStyleSheet("background-color: #f0f0f0;")  # Grey background for non-editable fields
            paramLayout1.addWidget(lbl)
            paramLayout1.addWidget(le)
        expLayout.addLayout(paramLayout1)
        
        # User Input Parameters (Repeated Units)
        self.alphachitin_unitInputs = {}
        paramLabels2 = ["a repeated units", "b repeated units", "c repeated units"]
        paramLayout2 = QHBoxLayout()
        for label in paramLabels2:
            lbl = QLabel(label + ":")
            lbl.setFont(Font)
            le = QLineEdit()
            le.setFont(Font)
            paramLayout2.addWidget(lbl)
            paramLayout2.addWidget(le)
            self.alphachitin_unitInputs[label.split()[0]] = le  # Store QLineEdit in a dictionary for easy access
        expLayout.addLayout(paramLayout2)


        # Modification Radio Buttons
        modRadioGroupLayout = QHBoxLayout()
        self.modRadio1 = QRadioButton("Deacetylation")
        self.modRadio2 = QRadioButton("Carboxylation")
        self.modRadio3 = QRadioButton("No Chemical Modification")
        self.modRadio1.setFont(Font)
        self.modRadio2.setFont(Font)
        self.modRadio3.setFont(Font)
        
        modRadioGroupLayout.addWidget(self.modRadio1)
        modRadioGroupLayout.addWidget(self.modRadio2)
        modRadioGroupLayout.addWidget(self.modRadio3)
        expLayout.addLayout(modRadioGroupLayout)
        
        # Setup Inputs and Connections
        self.chitin_setupModificationInputs()
        expLayout.addWidget(self.modificationInputsWidget)
        self.modRadio1.toggled.connect(lambda checked: self.chitin_updateModificationInputs("Deacetylation", checked))
        self.modRadio2.toggled.connect(lambda checked: self.chitin_updateModificationInputs("Carboxylation", checked))
        self.modRadio3.toggled.connect(lambda checked: self.chitin_updateModificationInputs("None", checked))
        # Initially hide the experimental parameters widget
        self.experimentalWidget.setVisible(False)
        layout.addWidget(self.experimentalWidget)
        
        # Toggle Experimental Widget Visibility
        self.radio1.toggled.connect(lambda checked: self.experimentalWidget.setVisible(checked if self.radio1.isChecked() else False))
        
        # Generate Structure Button
        self.invokeButton = QPushButton("Generate Structure")
        self.invokeButton.setFont(Font)
        self.invokeButton.setVisible(False)  # Initially hidden
        self.invokeButton.clicked.connect(self.alpha_chitin_invokeScript)  # Connect to invoke script logic
        layout.addWidget(self.invokeButton)
        
        # Finalize Layout
        self.AlphaAOptions.setLayout(layout)
        self.alphaStackedWidget.addWidget(self.AlphaAOptions)

    
    def chitin_setupModificationInputs(self):
        self.modificationInputsWidget = QWidget()
        modInputsLayout = QHBoxLayout(self.modificationInputsWidget)
        font = QFont("Arial", 13)

        # Degree of modification input
        self.alphachitin_degreeLabel = QLabel("Degree of Modification (≥0 and <1):")
        self.alphachitin_degreeLabel.setFont(font)
        self.alphachitin_degreeLineEdit = QLineEdit()
        self.alphachitin_degreeLineEdit.setFont(font)
        self.alphachitin_degreeLineEdit.setFixedSize(QSize(100, 30))
        modInputsLayout.addWidget(self.alphachitin_degreeLabel)
        modInputsLayout.addWidget(self.alphachitin_degreeLineEdit)

        # pH input (specific to Deacetylation)
        self.alphachitin_pHLabel = QLabel("pH:")
        self.alphachitin_pHLabel.setFont(font)
        self.alphachitin_pHLineEdit = QLineEdit()
        self.alphachitin_pHLineEdit.setFont(font)
        self.alphachitin_pHLineEdit.setFixedSize(QSize(100, 30))
        modInputsLayout.addWidget(self.alphachitin_pHLabel)
        modInputsLayout.addWidget(self.alphachitin_pHLineEdit)


        self.alphachitin_chainModelTypeLabel = QLabel("Chain Model Type:")
        self.alphachitin_chainModelTypeLabel.setFont(font)
        self.alphachitin_chainModelTypeselector = QComboBox()
        self.alphachitin_chainModelTypeselector.setFont(font)
        self.alphachitin_chainModelTypeselector.addItem(" ", True)
        self.alphachitin_chainModelTypeselector.addItem("CHARMM36 Infinite Chain Model", False)
        self.alphachitin_chainModelTypeselector.addItem("CHARMM36 Finite Chain Model", False)
        self.alphachitin_chainModelTypeselector.addItem("GLYCAM06 Infinite Chain Model (now not supported)", False)
        self.alphachitin_chainModelTypeselector.addItem("GLYCAM06 Finite Chain Model (now not supported)", False)
        modInputsLayout.addWidget(self.alphachitin_chainModelTypeLabel)
        modInputsLayout.addWidget(self.alphachitin_chainModelTypeselector)


        self.alphachitin_degreeLabel.setVisible(False)
        self.alphachitin_degreeLineEdit.setVisible(False)
        self.alphachitin_pHLabel.setVisible(False)
        self.alphachitin_pHLineEdit.setVisible(False)
        self.alphachitin_chainModelTypeLabel.setVisible(False)
        self.alphachitin_chainModelTypeselector.setVisible(False)


    def chitin_updateModificationInputs(self, modificationType, checked): 
        if checked:
            if modificationType == "Deacetylation":
                self.alphachitin_degreeLabel.setVisible(True)
                self.alphachitin_degreeLineEdit.setVisible(True)
                self.alphachitin_pHLabel.setVisible(True)
                self.alphachitin_pHLineEdit.setVisible(True)
                self.alphachitin_chainModelTypeLabel.setVisible(True)
                self.alphachitin_chainModelTypeselector.setVisible(True)
                self.invokeButton.setVisible(True)  # Hide "Generate Structure" button
            elif modificationType == "Carboxylation":
                self.alphachitin_degreeLabel.setVisible(True)
                self.alphachitin_degreeLineEdit.setVisible(True)
                self.alphachitin_pHLabel.setVisible(False)
                self.alphachitin_pHLineEdit.setVisible(False)
                self.alphachitin_chainModelTypeLabel.setVisible(True)
                self.alphachitin_chainModelTypeselector.setVisible(True)
                self.invokeButton.setVisible(True)  # Hide "Generate Structure" button
            elif modificationType == "None":
                self.alphachitin_degreeLabel.setVisible(False)
                self.alphachitin_degreeLineEdit.setVisible(False)
                self.alphachitin_pHLabel.setVisible(False)
                self.alphachitin_pHLineEdit.setVisible(False)
                self.alphachitin_chainModelTypeLabel.setVisible(True)
                self.alphachitin_chainModelTypeselector.setVisible(True)
                self.invokeButton.setVisible(True)  # Show "Generate Structure" button
        else:
            self.alphachitin_degreeLabel.setVisible(False)
            self.alphachitin_degreeLineEdit.setVisible(False)
            self.alphachitin_pHLabel.setVisible(False)
            self.alphachitin_pHLineEdit.setVisible(False)
            self.alphachitin_chainModelTypeLabel.setVisible(False)
            self.alphachitin_chainModelTypeselector.setVisible(False)
            self.invokeButton.setVisible(False)  
     
    def alpha_chitin_invokeScript(self):
            if self.modRadio3.isChecked():           #check for no chemical modification
                alphachitin_a_unit = self.alphachitin_unitInputs["a"].text()
                alphachitin_b_unit = self.alphachitin_unitInputs["b"].text()
                alphachitin_c_unit = self.alphachitin_unitInputs["c"].text()
                if not alphachitin_a_unit or not alphachitin_b_unit or not alphachitin_c_unit:
                    QMessageBox.warning(self, "Input Error", "Please fill in all repeated unit parameters.")
                    return
                alphachitin_modelType = self.alphachitin_chainModelTypeselector.currentText()
                base_dir = os.path.dirname(os.path.abspath(__file__))
                if alphachitin_modelType in ["CHARMM36 Infinite Chain Model", "CHARMM36 Finite Chain Model"]:
                    script_name = "alpha_chitin_A_infinite_experiment.py" if "Infinite" in alphachitin_modelType else "alpha_chitin_A_finite_experiment.py"
                    folder_name = "charmm36"
                elif alphachitin_modelType in ["GLYCAM06 Infinite Chain Model", "GLYCAM06 Finite Chain Model"]:
                    script_name = "alpha_chitin_A_infinite_experiment.py" if "Infinite" in alphachitin_modelType else "alpha_chitin_A_finite_experiment.py"
                    folder_name = "glycam06"
                script_path = os.path.join(base_dir, "function", "alpha-chitin-A", folder_name, script_name)
                command = ["python", script_path, alphachitin_a_unit, alphachitin_b_unit, alphachitin_c_unit]
                result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

                if result.returncode == 0:
                    output = result.stdout.strip()
                    self.none_alpha_chitinPopup(output)
                    self.none_alpha_chitinTopology()                    
                else:
                    QMessageBox.warning(self, "Generation Failed")

            if self.modRadio1.isChecked():           #check for no deacetylation
                alphachitin_a_unit = self.alphachitin_unitInputs["a"].text()
                alphachitin_b_unit = self.alphachitin_unitInputs["b"].text()
                alphachitin_c_unit = self.alphachitin_unitInputs["c"].text()
        
                if not alphachitin_a_unit or not alphachitin_b_unit or not alphachitin_c_unit:
                    QMessageBox.warning(self, "Input Error", "Please fill in all repeated unit parameters.")
                    return
                dda = self.alphachitin_degreeLineEdit.text()
                ph = self.alphachitin_pHLineEdit.text()
                alphachitin_modelType = self.alphachitin_chainModelTypeselector.currentText()
                base_dir = os.path.dirname(os.path.abspath(__file__))
                if alphachitin_modelType in ["CHARMM36 Infinite Chain Model", "CHARMM36 Finite Chain Model"]:
                    script_name = "alpha_chitin-modified-infinite.py" if "Infinite" in alphachitin_modelType else "alpha_chitin-modified-finite.py"
                    folder_name = "charmm36"
                elif alphachitin_modelType in ["GLYCAM06 Infinite Chain Model", "GLYCAM06 Finite Chain Model"]:
                    script_name = "alpha_chitin-modified-infinite.p" if "Infinite" in alphachitin_modelType else "alpha_chitin-modified-finite.py"
                    folder_name = "glycam06"
                script_path = os.path.join(base_dir, "function", "alpha-chitin-A-deacetylation", folder_name, script_name)
                command = ["python", script_path, alphachitin_a_unit, alphachitin_b_unit, alphachitin_c_unit, dda, ph]
                result = subprocess.run(command, stdout=subprocess.PIPE, text=True)
                output = result.stdout.strip()
                if result.returncode == 0:
                    output = result.stdout.strip()
                    self.deacetylation_alpha_chitinPopup(output)
                    self.deacetylation_alpha_chitinTopology()                    
                else:
                    QMessageBox.warning(self, "Generation Failed")

####non-chemical modification-chitin
    def none_alpha_chitinTopology(self):  #native chitin topology
        alphachitin_modelType = self.alphachitin_chainModelTypeselector.currentText()
        base_dir = os.path.dirname(os.path.abspath(__file__))
        script_name = "alpha-chitin_icm_topgen.py" if "Infinite" in alphachitin_modelType else "alpha-chitin_fcm_topgen.py"
        folder_name_i = "glycam06" if "GLYCAM06" in alphachitin_modelType else "charmm36"
        folder_name_j = "alpha-chitin"
        alphachitin_a_unit = self.alphachitin_unitInputs["a"].text()
        alphachitin_b_unit = self.alphachitin_unitInputs["b"].text()
        script_path = os.path.join(base_dir, "topology", folder_name_i, folder_name_j, script_name)
        command = ["python", script_path, alphachitin_a_unit, alphachitin_b_unit]
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if result.returncode == 0:
            self.none_alpha_chitinTopologyPopup()
        else:
            QMessageBox.warning(self, "Native α-chitin Topology Generation Failed")


    def none_alpha_chitinPopup(self, output):
        message = f"Native α-chitin-A was generated successfully"
        QMessageBox.information(self, "Build Result", message)

    def none_alpha_chitinTopologyPopup(self):
        alphachitin_modelType = self.alphachitin_chainModelTypeselector.currentText()
        file_name = "glycam06" if "GLYCAM06" in alphachitin_modelType else "CHARMM36"
        message = f"{file_name} Topology File for Native α-chitin Generated Successfully."
        QMessageBox.information(self, "Topology Build Result", message)


####deacetylation chitin
    def deacetylation_alpha_chitinTopology(self):  #native chitin topology
        alphachitin_modelType = self.alphachitin_chainModelTypeselector.currentText()
        base_dir = os.path.dirname(os.path.abspath(__file__))
        script_name = "modification_alpha-chitin_icm_topgen.py" if "Infinite" in alphachitin_modelType else "modification_alpha-chitin_fcm_topgen.py"
        folder_name_i = "glycam06" if "GLYCAM06" in alphachitin_modelType else "charmm36"
        folder_name_j = "alpha-chitin"
        script_path = os.path.join(base_dir, "topology", folder_name_i, folder_name_j, script_name)
        command = ["python", script_path]
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if result.returncode == 0:
            self.deacetylation_alpha_chitinTopologyPopup()
        else:
            QMessageBox.warning(self, "Native α-chitin Topology Generation Failed")


    def deacetylation_alpha_chitinPopup(self, output): #deacetylation chitin
        parts = output.split(',')
        dda = parts[0].split(':')[1].strip()
        ph = parts[1].split(':')[1].strip()
        units = parts[2].split(':')[1].strip()
        message = f"Deacetylation α-chitin-A was generated successfully!\nActual DDA: {dda}\nActual pH: {ph}\nDeprotonated units: {units}"
        QMessageBox.information(self, "Build Result", message)
        
    def deacetylation_alpha_chitinTopologyPopup(self):
        alphachitin_modelType = self.alphachitin_chainModelTypeselector.currentText()
        file_name = "glycam06" if "GLYCAM06" in alphachitin_modelType else "CHARMM36"
        message = f"{file_name} Topology File for Deacetylation α-chitin Generated Successfully."
        QMessageBox.information(self, "Topology Build Result", message)

##chitin-b
    def setupAlphaBOptions(self):
        groupBox = QWidget()
        self.alphaBOptions = QWidget()
        layout = QHBoxLayout()  
        layout.setAlignment(Qt.AlignTop)    

        font = QFont("Arial", 13)
        radio1 = QRadioButton("Experimental Data")
        radio2 = QRadioButton("DFT-Optimization Data")
        radio3 = QRadioButton("User-Self Defined")
    
        radio1.setFont(font)
        radio2.setFont(font)
        radio3.setFont(font)
    
        layout.addWidget(radio1)
        layout.addWidget(radio2)
        layout.addWidget(radio3)
    
        self.alphaBOptions.setLayout(layout)
        self.alphaStackedWidget.addWidget(self.alphaBOptions)  # Add to stacked widget
        radio1.toggled.connect(lambda: self.handleAlphaChitinRadioButton(type, "Experimental", radio1.isChecked()))
        layout.addWidget(radio1)
        layout.addWidget(radio2)
        layout.addWidget(radio3) 
        # Additional input fields, initially hidden
        self.fixedValueLabel = QLabel("Fixed Value: 12345")  # Example fixed value
        self.fixedValueLabel.setVisible(False)
        layout.addWidget(self.fixedValueLabel)
        self.editableInput = QLineEdit("Enter parameter here...")
        self.editableInput.setVisible(False)
        layout.addWidget(self.editableInput)

        self.alphaStackedWidget.addWidget(groupBox)
        
    def handleAlphaChitinRadioButton(self, type, dataOption, isChecked):
        if isChecked and dataOption == "Experimental":
            self.fixedValueLabel.setVisible(True)
            self.editableInput.setVisible(True)
        else:
            self.fixedValueLabel.setVisible(False)
            self.editableInput.setVisible(False)
